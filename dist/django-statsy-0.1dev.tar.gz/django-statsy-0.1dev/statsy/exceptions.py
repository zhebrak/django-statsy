# coding: utf-8


class StatsyException(Exception):
    pass


class StatsyDisabledException(StatsyException):
    pass
